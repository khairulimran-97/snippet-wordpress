<?php
/*
Plugin Name: Recurring Commission Plugin
Description: Plugin to manage recurring commissions with a custom database table.
Version: 1.0
Author: Your Name
*/

// Create the custom database table on plugin activation
function create_recurring_commission_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'recurring_commission';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id INT(11) NOT NULL AUTO_INCREMENT,
        quantity INT(11) NOT NULL,
        commission_rate FLOAT NOT NULL,
        created_at DATETIME NOT NULL,
        modified_at DATETIME NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'create_recurring_commission_table');

// Add the menu item in the WordPress admin dashboard
function recurring_commission_menu() {
    add_menu_page(
        'Recurring Commission',
        'Recurring Commission',
        'manage_options',
        'recurring-commission',
        'recurring_commission_page',
        'dashicons-chart-line',
        30
    );
}
add_action('admin_menu', 'recurring_commission_menu');

// Display the table and handle CRUD operations
function recurring_commission_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'recurring_commission';

    $notice = '';

    // Handle form submission
    if (isset($_POST['submit'])) {
        $quantity = intval($_POST['quantity']);
        $commission_rate = floatval($_POST['commission_rate']);
        $created_at = current_time('mysql');
        $modified_at = $created_at;

        // Check if the quantity already exists in the table
        $existing_commission = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE quantity = %d", $quantity), ARRAY_A);
        if ($existing_commission) {
            // Display the popup message
            echo '<div id="popup" style="display: flex; justify-content: center; align-items: center; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.5); z-index: 9999;">';
            echo '<div style="background-color: #fff; padding: 20px; border-radius: 5px; text-align: center;">';
            echo '<p>A record with the same quantity already exists.</p>';
            echo '<button onclick="closePopup()">Close</button>';
            echo '</div>';
            echo '</div>';
            echo '<script>';
            echo 'function closePopup() {';
            echo 'document.getElementById("popup").style.display = "none";';
            echo '}';
            echo '</script>';
        } else {
            // Insert the new record
            $wpdb->insert(
                $table_name,
                array(
                    'quantity' => $quantity,
                    'commission_rate' => $commission_rate,
                    'created_at' => $created_at,
                    'modified_at' => $modified_at
                ),
                array('%d', '%f', '%s', '%s')
            );

            $notice = 'Record added successfully.';
        }
    }

// Handle update operation
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $quantity = intval($_POST['quantity']);
    $commission_rate = floatval($_POST['commission_rate']);
    $modified_at = current_time('mysql');

    // Retrieve current data for the notice message
    $current_data = $wpdb->get_row($wpdb->prepare("SELECT quantity, commission_rate FROM $table_name WHERE id = %d", $id), ARRAY_A);

    $wpdb->update(
        $table_name,
        array(
            'quantity' => $quantity,
            'commission_rate' => $commission_rate,
            'modified_at' => $modified_at
        ),
        array('id' => $id),
        array('%d', '%f', '%s'),
        array('%d')
    );

    // Modify the notice message
    if ($current_data['quantity'] == $quantity && $current_data['commission_rate'] == $commission_rate) {
        $notice = 'No changes made. Quantity and commission rate remain the same.';
    } elseif ($current_data['quantity'] == $quantity) {
        $notice = sprintf('Commission rate updated successfully for quantity %d.', $quantity);
    } elseif ($current_data['commission_rate'] == $commission_rate) {
        $notice = sprintf('Quantity updated successfully for commission rate %.2f.', $commission_rate);
    } elseif ($current_data['quantity'] != $quantity && $current_data['commission_rate'] != $commission_rate) {
        $notice = sprintf('Record updated successfully. Commission rate updated for quantity %d and commission rate %.2f.', $quantity, $commission_rate);
    }
}


    // Handle delete operation
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $wpdb->delete($table_name, array('id' => $id), array('%d'));

        $notice = 'Record deleted successfully.';
    }

    // Fetch existing data
    $commissions = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

    // Display the form and table
    ?>
    <style>
        .add {
            margin-bottom: 30px;
			margin-top:30px;
	
        }

        .button,
        .delete-button {
            display: inline-block;
            padding: 8px 16px;
            line-height: 1;
            vertical-align: middle;
            text-align: center;
            text-decoration: none;
        }

        .button {
            background-color: #4CAF50;
            color: white;
            border: none;
        }

        .delete-button {
            background-color: #f44336;
            color: white;
            border: none;
        }
    </style>

    <div class="wrap">
        <h1>Recurring Commission For Monthly</h1>

        <?php if (!empty($notice)) : ?>
            <div class="notice notice-success">
                <p><?php echo $notice; ?></p>
            </div>
        <?php endif; ?>

        <form class="add" method="post" action="">
            <label for="quantity">Quantity:</label>
            <input type="number" name="quantity" id="quantity" required>

            <label for="commission_rate">Commission Rate (%):</label>
            <input type="number" step="1" name="commission_rate" id="commission_rate" required>

            <input type="submit" name="submit" value="Add" class="button button-primary">
        </form>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Quantity</th>
                    <th>Commission Rate (%)</th>
                    <th>Created At</th>
                    <th>Modified At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($commissions as $commission) : ?>
                    <tr>
                        <form method="post" action="">
                            <td><input type="number" name="quantity" value="<?php echo $commission['quantity']; ?>" required></td>
                            <td><input type="number" step="0.01" name="commission_rate" value="<?php echo $commission['commission_rate']; ?>" required></td>
                            <td><?php echo $commission['created_at']; ?></td>
                            <td><?php echo $commission['modified_at']; ?></td>
                            <td>
                                <input type="hidden" name="id" value="<?php echo $commission['id']; ?>">
                                <input type="submit" name="update" value="Update" class="button button-primary">
                                <a href="?page=recurring-commission&action=delete&id=<?php echo $commission['id']; ?>" class="delete-button" onclick="return confirm('Are you sure you want to delete this item?')">Delete</a>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Display the notice
function recurring_commission_admin_notice() {
    if (isset($_GET['notice'])) {
        ?>
        <div class="notice notice-success">
            <p><?php echo esc_html($_GET['notice']); ?></p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'recurring_commission_admin_notice');
